import { Component, OnInit } from '@angular/core';
import { Banker } from '../model/banker';
import { BankerService } from '../service/banker.service';
import { LoanMaster } from '../model/loan-master';
import { Customer } from '../model/customer';

@Component({
  selector: 'app-preclosure-approval',
  templateUrl: './preclosure-approval.component.html',
  styleUrls: ['./preclosure-approval.component.css']
})
export class PreclosureApprovalComponent implements OnInit {
  loggedInBanker: Banker;
  preClosureApplied:LoanMaster[];
  loanAppSelected:boolean;
  selectLoan:LoanMaster;
  isLoanApproved:boolean;
  isLoanDeclined:boolean;
  verifiedLoan:LoanMaster;
  clickForDetails: boolean;
  currentCustomer: Customer;
  toProceed: boolean;

  constructor(private bankerService: BankerService) { 
    this.preClosureApplied=[];
    this.loanAppSelected=false;
    this.selectLoan=new LoanMaster();
    this.isLoanApproved=false;
    this.isLoanDeclined=false;
    this.clickForDetails = false;
    this.verifiedLoan=new LoanMaster();
    this.toProceed = false;
  }

  ngOnInit() {
    this.loggedInBanker = this.bankerService.loggedInBanker;
    this.loadVerificationPreClosures();
    console.log(this.preClosureApplied);
  }

  loadVerificationPreClosures() {
    this.bankerService.getPreClosureAppliedPerBanker(this.bankerService.loggedInBanker.userId).subscribe(
      (data) => {
        this.preClosureApplied = data;
        console.log(this.preClosureApplied);
      }
    );
  }

  onLoanAppSelection() {
    this.loanAppSelected = true;
    console.log(this.selectLoan);
    this.bankerService.getCustomer(this.selectLoan.customerUserId).subscribe(
      (data)  => {
      this.currentCustomer = data;
      this.bankerService.saveCurrentCustomer = this.currentCustomer;
      console.log(this.currentCustomer);
      }
    )
  }
  doYouWantToProceed(){
    this.toProceed = true;
  }
  
  approve(choice:number) {
    console.log(this.selectLoan);
    if (this.selectLoan.applicationNumber == null) {
      this.isLoanApproved = false;
      this.isLoanDeclined = false;
      alert("Please select a pre-closure for verification.");
    }
    else {
      console.log(choice);
      console.log(this.selectLoan);
      this.bankerService.verifyPreClosure(this.selectLoan, choice).subscribe(
        (data) => {
          this.verifiedLoan = data;
          console.log(this.verifiedLoan);
        }
      );
      if (choice == 1) {
        this.isLoanApproved = true;
        this.isLoanDeclined = false;
      } else {
        this.isLoanApproved = false;
        this.isLoanDeclined = true;
      }
    }
  }
  logoutBanker() {
    this.bankerService.logoutBanker();
  }

  gotoHome() {
    this.bankerService.goToHome();
  }
  gotoApproveLoan() {
    this.bankerService.goToApproveLoan();
  }
}
