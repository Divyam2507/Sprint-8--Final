import { Component, OnInit } from '@angular/core';
import { LoginVerifyService } from '../service/login-verify.service';
import { Router } from '@angular/router';
import { BankerService } from '../service/banker.service';
import { Banker } from '../model/banker';
import { LoanMaster } from '../model/loan-master';

@Component({
  selector: 'app-banker-dashboard',
  templateUrl: './banker-dashboard.component.html',
  styleUrls: ['./banker-dashboard.component.css']
})
export class BankerDashboardComponent implements OnInit {
  banker: Banker;
  loggedInBanker: Banker;
  loanApplied: LoanMaster[];
  preApplied : LoanMaster[];

  constructor(private bankerService: BankerService,
    private loginVerifyService: LoginVerifyService,
    private router: Router) { 
      this.loanApplied=[];
      this.preApplied=[];
    }

  ngOnInit() {
    this.loggedInBanker = this.bankerService.loggedInBanker;
    this.loadVerificationLoans();
    this.loadPreVerificationLoans();
  }
  loadVerificationLoans(){ 
  this.bankerService.getLoanAppliedDetails().subscribe(
    (data) => {
      this.loanApplied= data;
    }
  );
}
  loadPreVerificationLoans(){
    this.bankerService.getPreClosureAppliedDetails().subscribe(
      (data) => {
        this.preApplied= data;
      }
    );
  }

  logoutBanker() {
    this.bankerService.logoutBanker();
  }

}


