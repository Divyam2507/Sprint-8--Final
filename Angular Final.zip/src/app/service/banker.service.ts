import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';
import { LoanType } from 'src/app/model/loan-type';
import { Customer } from '../model/customer';
import { LoanEmiDetails } from '../model/loan-emi-details';
import { LoanMaster } from '../model/loan-master';
import { Banker } from '../model/banker';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class BankerService {
  baseUrl: string;
  loggedInBanker: Banker;
  saveCurrentCustomer: Customer;

  constructor(private http: HttpClient, private router: Router) {
    this.baseUrl = `${environment.baseMwUrl}/IBS/Banker`;
  }

  getLoanAppliedDetails(): Observable<LoanMaster[]> {
    return this.http.get<LoanMaster[]>(`${this.baseUrl}/appliedLoans`);
  }
  getPreClosureAppliedDetails(): Observable<LoanMaster[]> {
    return this.http.get<LoanMaster[]>(`${this.baseUrl}/preClosureLoans`);
  }
  getLoanAppliedPerBanker(userId: string): Observable<LoanMaster[]> {
    console.log(userId);
    return this.http.get<LoanMaster[]>(`${this.baseUrl}/${userId}`);
  }
  getPreClosureAppliedPerBanker(userId: string): Observable<LoanMaster[]> {
    return this.http.get<LoanMaster[]>(`${this.baseUrl}/bankerVerifyPreClosure/${userId}`);
  }
  verifyLoan(loanMaster: LoanMaster, choice: number): Observable<LoanMaster> {
    console.log(choice);
    console.log(loanMaster);
    return this.http.post<LoanMaster>(`${this.baseUrl}/${choice}`, loanMaster);
  }

  getCustomer(userId: String): Observable<Customer> {
    return this.http.get<Customer>(`${this.baseUrl}/getCustomer/${userId}`);
  }

  logoutBanker() {
    this.loggedInBanker = undefined;
    sessionStorage.removeItem('userId');
    console.log(this.loggedInBanker);
    this.router.navigateByUrl("/");
  }
  goToHome() {
    this.router.navigateByUrl("bankDashboard")
  }

  goToApprovePreclosure() {
    this.router.navigateByUrl("bankDashboard/approvePreclosure")
  }

  goToApproveLoan() {
    this.router.navigateByUrl("bankDashboard/approveLoan")
  }
verifyPreClosure(loanMaster:LoanMaster, choice:number):Observable<LoanMaster>{
    console.log(choice);
    console.log(loanMaster);
    return this.http.post<LoanMaster>(`${this.baseUrl}/preClose/${choice}`, loanMaster);
  }

}
