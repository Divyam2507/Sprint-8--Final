import { TestBed } from '@angular/core/testing';

import { PayEmiService } from './pay-emi.service';

describe('PayEmiService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: PayEmiService = TestBed.get(PayEmiService);
    expect(service).toBeTruthy();
  });
});
