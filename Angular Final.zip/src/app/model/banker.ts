export class Banker {
    bankerId:number;
	userId:string;
	password: string;
	verifyApplicationNumber: number;
	preClosureVerifyLoanNumber: number;
	remarks: string;		
}
