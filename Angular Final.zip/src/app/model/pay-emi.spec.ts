import { PayEmi } from './pay-emi';

describe('PayEmi', () => {
  it('should create an instance', () => {
    expect(new PayEmi()).toBeTruthy();
  });
});
