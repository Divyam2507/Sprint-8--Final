export class LoanType {
    typeId: number;
    loanType: string;
    interestRate: number;
    maximumLimit: number;
    minimumLimit: number 
}
 
enum LoanTypes {
    HOME_LOAN,
    EDUCATION_LOAN,
    PERSONAL_LOAN,
    VEHICLE_LOAN
}