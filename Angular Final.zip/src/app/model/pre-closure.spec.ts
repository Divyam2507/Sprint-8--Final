import { PreClosure } from './pre-closure';

describe('PreClosure', () => {
  it('should create an instance', () => {
    expect(new PreClosure()).toBeTruthy();
  });
});
