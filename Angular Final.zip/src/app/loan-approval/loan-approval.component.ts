import { Component, OnInit } from '@angular/core';
import { BankerService } from '../service/banker.service';
import { LoanMaster } from '../model/loan-master';
import { Banker } from '../model/banker';
import { Customer } from '../model/customer';

@Component({
  selector: 'app-loan-approval',
  templateUrl: './loan-approval.component.html',
  styleUrls: ['./loan-approval.component.css']
})
export class LoanApprovalComponent implements OnInit {
  loanApplied: LoanMaster[];
  loggedInBanker: Banker;
  selectLoan: LoanMaster;
  loanAppSelected: boolean;
  isLoanApproved: boolean;
  isLoanDeclined: boolean;
  verifiedLoan: LoanMaster;
  currentCustomer : Customer;
  toProceed: boolean;

  constructor(private bankerService: BankerService) {
    this.loanApplied = [];
    this.loggedInBanker = null;
    this.loanAppSelected = false;
    this.isLoanApproved = false;
    this.isLoanDeclined = false;
    this.selectLoan = new LoanMaster();
    this.verifiedLoan=new LoanMaster();
    this.currentCustomer = new Customer;
    this.toProceed = false;
  }

  ngOnInit() {
    this.loggedInBanker = this.bankerService.loggedInBanker;
    this.loadVerificationLoans();
    console.log(this.loanApplied);
  }

  loadVerificationLoans() {
    this.bankerService.getLoanAppliedPerBanker(this.bankerService.loggedInBanker.userId).subscribe(
      (data) => {
        this.loanApplied = data;
        console.log(this.loanApplied);
      }
    );
  }
  onLoanAppSelection() {
    this.loanAppSelected = true;
    console.log(this.selectLoan);
    this.bankerService.getCustomer(this.selectLoan.customerUserId).subscribe(
      (data)  => {
      this.currentCustomer = data;
      this.bankerService.saveCurrentCustomer = this.currentCustomer;
      console.log(this.currentCustomer);
      }
    )

    
  }
  doYouWantToProceed(){
    this.toProceed = true;
  }

  approve(choice:number) {
    console.log(this.selectLoan);
    if (this.selectLoan.applicationNumber == null) {
      this.isLoanApproved = false;
      this.isLoanDeclined = false;
      alert("Please select a loan for verification.");
    }
    else {
      console.log(choice);
      console.log(this.selectLoan);
      this.bankerService.verifyLoan(this.selectLoan, choice).subscribe(
        (data) => {
          this.verifiedLoan = data;
          console.log(this.verifiedLoan);
        }
      );
      if (choice == 1) {
        this.isLoanApproved = true;
        this.isLoanDeclined = false;
      } else {
        this.isLoanApproved = false;
        this.isLoanDeclined = true;
      }



    }
  }

  logoutBanker() {
    this.bankerService.logoutBanker();
  }

  gotoHome() {
    this.bankerService.goToHome();
  }
  gotoApprovePreclosure() {
    this.bankerService.goToApprovePreclosure();
  }
}

