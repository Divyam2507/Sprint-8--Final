import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ApplyPreclosureComponent } from './apply-preclosure.component';

describe('ApplyPreclosureComponent', () => {
  let component: ApplyPreclosureComponent;
  let fixture: ComponentFixture<ApplyPreclosureComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ApplyPreclosureComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ApplyPreclosureComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
