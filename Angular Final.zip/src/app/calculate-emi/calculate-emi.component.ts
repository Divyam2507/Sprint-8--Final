
import { Component, OnInit, ɵConsole } from '@angular/core';
import { VisitorService } from '../service/visitor.service';
import { LoanMaster } from '../model/loan-master';
import { LoanEmiDetails } from '../model/loan-emi-details';
import { LoanType } from '../model/loan-type';
import { Router } from '@angular/router';

@Component({
  selector: 'app-calculate-emi',
  templateUrl: './calculate-emi.component.html',
  styleUrls: ['./calculate-emi.component.css']
})
export class CalculateEmiComponent implements OnInit {

  newLoan: LoanMaster;
  rate: number;
  onePlusRPoweredN: number;
  emiAmount: number;
  emiNumber: number;
  emiAmountFinal: string;
  isEmiCheck: boolean;
  isViewDetails: boolean;
  paidInterest: number;
  paidPrinciple: number;
  emiDetails: LoanEmiDetails[];
  limitCheck: boolean;
  tenureLimitCheck: boolean;
  maxLimit: number;
  minLimit: number;
  loanTypeSpec: LoanType;
  a: number;
  typeId: number;

  constructor(
    private visitorService: VisitorService, private router: Router) {
    this.newLoan = new LoanMaster();
    this.loanTypeSpec = new LoanType();
    this.isEmiCheck = false;
    this.emiDetails = [];
    this.isViewDetails = false;
    this.limitCheck = false;
    this.tenureLimitCheck = false;
    this.maxLimit = 0;
    this.minLimit = 0;
    this.rate = 0;
  }

  ngOnInit() {
    this.visitorService.currenttypeId.subscribe(typeId => this.typeId = typeId);
    this.getLoanTypeById();
    
  }


  checkLimits() {
    this.isEmiCheck = false;
    this.isViewDetails = false;
    this.maxLimit = this.loanTypeSpec.maximumLimit;
    this.minLimit = this.loanTypeSpec.minimumLimit;
    if (this.newLoan.loanAmount <= this.maxLimit && this.newLoan.loanAmount >= this.minLimit) {
      this.isEmiCheck = false;
      this.limitCheck = false;
    } else {
      this.limitCheck = true;
    }
    console.log(this.limitCheck);
  }
  checkTenureLimits() {
    this.isEmiCheck = false;
    this.isViewDetails = false;
    if (this.newLoan.loanTenure <= 240 && this.newLoan.loanAmount >= 1) {
      this.isEmiCheck = false;
      this.tenureLimitCheck = false;
    } else {
      this.tenureLimitCheck = true;
    }
    console.log(this.tenureLimitCheck);
  }

  calcEmi() {
    this.isEmiCheck = true;
    this.rate = this.loanTypeSpec.interestRate;
    this.onePlusRPoweredN = Math.pow(((this.rate / 1200) + 1), this.newLoan.loanTenure);
    this.emiAmount = (this.newLoan.loanAmount) * ((this.rate / 1200 * this.onePlusRPoweredN) / (this.onePlusRPoweredN - 1));
    this.newLoan.emiAmount = this.emiAmount;
    this.newLoan.balance = this.newLoan.loanAmount;
    this.newLoan.loanInterest = this.rate;
    this.emiAmountFinal = (this.emiAmount).toFixed(2);
    return this.emiAmountFinal;
  }

  viewDetails() {
    this.isViewDetails = true;
    this.visitorService.getDisplay(this.newLoan).subscribe(
      (data) => {
        this.emiDetails = data;
      }
    );
  }


  getLoanTypeById() {
    this.visitorService.getLoanTypeById().subscribe(
      (data) => {
        this.loanTypeSpec = data;
        console.log(this.loanTypeSpec.loanType);
      }
    );
  }

  gotoHome() {
    this.visitorService.goToHome();
  }
}