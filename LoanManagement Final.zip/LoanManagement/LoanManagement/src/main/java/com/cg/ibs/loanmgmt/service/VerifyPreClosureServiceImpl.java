package com.cg.ibs.loanmgmt.service;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ibs.loanmgmt.dao.AccountDao;
import com.cg.ibs.loanmgmt.dao.BankerDao;
import com.cg.ibs.loanmgmt.dao.EmiTransactionDao;
import com.cg.ibs.loanmgmt.dao.LoanMasterDao;
import com.cg.ibs.loanmgmt.dao.TransactionDao;
import com.cg.ibs.loanmgmt.dao.VerificationDetailsDao;
import com.cg.ibs.loanmgmt.entities.Account;
import com.cg.ibs.loanmgmt.entities.Banker;
import com.cg.ibs.loanmgmt.entities.EmiTransaction;
import com.cg.ibs.loanmgmt.entities.LoanMasterEntity;
import com.cg.ibs.loanmgmt.entities.LoanStatus;
import com.cg.ibs.loanmgmt.entities.Transaction;
import com.cg.ibs.loanmgmt.entities.TransactionMode;
import com.cg.ibs.loanmgmt.entities.TransactionType;
import com.cg.ibs.loanmgmt.entities.VerificationDetailsEntity;
import com.cg.ibs.loanmgmt.ibsexception.ExceptionMessages;
import com.cg.ibs.loanmgmt.ibsexception.IBSException;
import com.cg.ibs.loanmgmt.model.BankerModel;
import com.cg.ibs.loanmgmt.model.LoanMasterModel;

@Service("verifyPreClosureService")
public class VerifyPreClosureServiceImpl implements VerifyPreClosureService {
	@Autowired
	BankerDao bankerDao;
	@Autowired
	LoanMasterDao loanMasterDao;
	@Autowired
	AccountDao accountDao;
	@Autowired
	TransactionDao transactionDao;
	@Autowired
	EmiTransactionDao emiTransactionDao;
	@Autowired
	ApplyLoanService applyLoanService;
	@Autowired
	VerificationDetailsDao verificationDetailsDao;

	@Override
	public List<LoanMasterModel> findPreClosureLoansToBeVerified(String userId) {
		List<LoanMasterEntity> pendingPreClosureLoans = loanMasterDao.findPreClosureLoansToBeVerified(bankerDao.findByUserId(userId));
		List<LoanMasterModel> pendingPreClosureLoansModel = new ArrayList<>();
		if (pendingPreClosureLoans.isEmpty()) {
			pendingPreClosureLoansModel = null;
		} else {
			for (LoanMasterEntity loanMasterEntity : pendingPreClosureLoans) {
				LoanMasterModel loanMasterModel = applyLoanService.valueOf(loanMasterEntity);
				System.out.println(loanMasterModel.getPreclosureAppliedDate());
				System.out.println(loanMasterEntity.getPre_Closure_Approver().getUserId());
				pendingPreClosureLoansModel.add(loanMasterModel);
			}
		}
		return pendingPreClosureLoansModel;
	}

	@Override
	public LoanMasterModel findPreClosureLoanToBeVerified(BigInteger loanAccountNumber) {
		LoanMasterEntity loanMasterEntity = loanMasterDao.findByLoanAccountNumber(loanAccountNumber);
		return applyLoanService.valueOf(loanMasterEntity);
	}
	@Transactional
	@Override
	public LoanMasterModel verifyPreClosure(LoanMasterModel loanMasterModel, Integer choice) throws IBSException {
		LoanMasterEntity loanMasterEntity = loanMasterDao.findByLoanAccountNumber(loanMasterModel.getLoanAccountNumber());
		VerificationDetailsEntity details = new VerificationDetailsEntity();
		switch (choice) {
		case 1:
			loanMasterEntity.setPreclosureApprovedDate(LocalDate.now());
			loanMasterEntity.setStatus(LoanStatus.PRE_CLOSED);
			loanMasterEntity.getSavings_Account().setBalance(loanMasterEntity.getSavings_Account().getBalance().subtract(loanMasterEntity.getBalance()));
			debitPreClosureTransaction(loanMasterEntity);	//debit Transaction
			creditPreClosureTransaction(loanMasterEntity); //credit Transaction
			loanMasterEntity.setNextEmiDate(null);
			loanMasterEntity.setLoanClosedDate(loanMasterEntity.getPreclosureApprovedDate());
			details.setApplicationNumber(loanMasterEntity.getApplicationNumber());
			details.setQueryStatus(LoanStatus.PRE_CLOSED);
			details.setRemarks(loanMasterModel.getRemarks());
			loanMasterEntity.setBalance(new BigDecimal("0.0"));
			loanMasterEntity = loanMasterDao.save(loanMasterEntity);
			details = verificationDetailsDao.save(details);
			break;

		case 2:
			loanMasterEntity.setPreclosureDeniedDate(LocalDate.now());
			loanMasterEntity.setStatus(LoanStatus.APPROVED);
			details.setApplicationNumber(loanMasterEntity.getApplicationNumber());
			details.setQueryStatus(LoanStatus.PRE_CLOSURE_DENIED);
			details.setRemarks(loanMasterModel.getRemarks());
			loanMasterEntity = loanMasterDao.save(loanMasterEntity);
			details = verificationDetailsDao.save(details);
			break;
		}
		loanMasterModel = applyLoanService.valueOf(loanMasterEntity);
		loanMasterModel.setRemarks(details.getRemarks());
		return loanMasterModel;
	}

	private Transaction debitPreClosureTransaction(LoanMasterEntity loanMasterEntity) throws IBSException {
		Transaction transaction = new Transaction();
		transaction.setAccount(loanMasterEntity.getSavings_Account());
		transaction.setCurrentBalance(loanMasterEntity.getSavings_Account().getBalance());
		transaction.setReferenceId(loanMasterEntity.getLoanAccountNumber().toString());
		transaction.setTransactionAmount(loanMasterEntity.getBalance());
		transaction.setTransactionDate(LocalDateTime.now());
		transaction.setTransactionDescription(
				"Payment PreClosure of loan : " + loanMasterEntity.getLoanAccountNumber());
		transaction.setTransactionMode(TransactionMode.ONLINE);
		transaction.setTransactionType(TransactionType.DEBIT);
		try {
			transactionDao.save(transaction);
		} catch (Exception e) {
			e.printStackTrace();
			throw new IBSException(ExceptionMessages.MESSAGEFORNOTRANSACTION);
		}
		transactionDao.save(transaction);
		return transaction;
	}

	private EmiTransaction creditPreClosureTransaction(LoanMasterEntity loanMasterEntity) throws IBSException {
		EmiTransaction transaction = new EmiTransaction();
		transaction.setEmiNumber(null);
		transaction.setLoanMasterAccountNumber(loanMasterEntity);
		transaction.setTransactionAmount(loanMasterEntity.getEmiAmount());
		transaction.setTransactionDate(LocalDateTime.now());
		transaction.setTransactionDescription(
				"Payment PreClosure of loan:" + loanMasterEntity.getLoanAccountNumber());
		transaction.setTransactionMode(TransactionMode.ONLINE);
		transaction.setTransactionType(TransactionType.CREDIT);
		transaction.setReferenceId(loanMasterEntity.getSavings_Account().getAccNo().toString());
		try {
			emiTransactionDao.save(transaction);
		} catch (Exception e) {
			throw new IBSException(ExceptionMessages.MESSAGEFORNOTRANSACTION);
		}
		return transaction;
	}

}
