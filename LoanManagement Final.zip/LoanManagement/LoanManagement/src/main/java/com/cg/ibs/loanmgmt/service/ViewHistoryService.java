package com.cg.ibs.loanmgmt.service;

import java.util.List;

import com.cg.ibs.loanmgmt.ibsexception.IBSException;
import com.cg.ibs.loanmgmt.model.LoanMasterModel;

public interface ViewHistoryService {
	List<LoanMasterModel> getAllLoans(String userId) throws IBSException;
}
