package com.cg.ibs.loanmgmt.controller;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.ibs.loanmgmt.ibsexception.ExceptionMessages;
import com.cg.ibs.loanmgmt.ibsexception.IBSException;
import com.cg.ibs.loanmgmt.model.BankerModel;
import com.cg.ibs.loanmgmt.model.CustomerModel;
import com.cg.ibs.loanmgmt.model.LoanDetailsDisplay;
import com.cg.ibs.loanmgmt.model.LoanMasterModel;
import com.cg.ibs.loanmgmt.model.LoanTypeModel;
import com.cg.ibs.loanmgmt.model.LoginModel;
import com.cg.ibs.loanmgmt.service.VisitorService;

@RestController
@RequestMapping("/IBS")
@CrossOrigin
public class HomeController {

	@Autowired
	private VisitorService visitorService;

	@GetMapping("/{typeId}")
	public ResponseEntity<LoanTypeModel> getLoanType(@PathVariable("typeId") Integer typeId) {
		ResponseEntity<LoanTypeModel> result = null;
		System.out.println("hello");
		LoanTypeModel loanTypeModel = visitorService.getTypeOfLoan(typeId);
		if (null == loanTypeModel) {
			result = new ResponseEntity<>(HttpStatus.NOT_FOUND);
		} else {
			result = new ResponseEntity<>(loanTypeModel, HttpStatus.OK);
		}
		return result;
	}

	@PostMapping
	public ResponseEntity<?> login(@RequestBody LoginModel loginModel) throws IBSException {
		System.out.println("I am in controller");
		ResponseEntity<?> result = null;
		CustomerModel loggedInCustomerModel;
		BankerModel loggedInBankerModel;
		if (null == loginModel) {
			throw new IBSException(ExceptionMessages.MESSAGEFORWRONGINPUT);
		} else {
			switch (loginModel.getRole()) {
			case "CUSTOMER":
				loggedInCustomerModel = visitorService.verifyCustomerLogin(loginModel.getUserId(),
						loginModel.getPassword());
				
					result = new ResponseEntity<>(loggedInCustomerModel, HttpStatus.OK);
				
				break;
			case "BANKER":
				loggedInBankerModel = visitorService.verifyBankerLogin(loginModel.getUserId(),
						loginModel.getPassword());
				if (null == loggedInBankerModel) {
					result = new ResponseEntity<>(HttpStatus.NOT_FOUND);
				} else {
					result = new ResponseEntity<>(loggedInBankerModel, HttpStatus.OK);
				}
				break;
			}
		}
		return result;
	}

	@PostMapping("/table")
	public ResponseEntity<List<LoanDetailsDisplay>> emiTable(@RequestBody LoanMasterModel loanMasterModel) {
		//LoanTypeModel loanTypeModel = visitorService.getTypeOfLoan(loanMasterModel.getLoanTypeId());
		//loanMasterModel.setLoanInterest(loanTypeModel.getInterestRate());
		ResponseEntity<List<LoanDetailsDisplay>> result = null;
		List<LoanDetailsDisplay> tableList = new ArrayList<LoanDetailsDisplay>();
		if (loanMasterModel.getLoanAmount().equals(null) || loanMasterModel.getLoanTenure().equals(null)) {
			result = new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		} else {
			for (int i = 0; i < loanMasterModel.getLoanTenure(); i++) {
				BigDecimal interest = visitorService.calculatePaidInterest(loanMasterModel).setScale(4,
						RoundingMode.HALF_UP);
				BigDecimal principle = visitorService.calculatePaidPrinciple(loanMasterModel).setScale(4,
						RoundingMode.HALF_UP);
				loanMasterModel
						.setBalance(loanMasterModel.getBalance().subtract(principle).setScale(4, RoundingMode.HALF_UP));
				LoanDetailsDisplay display = new LoanDetailsDisplay(i+1,loanMasterModel.getEmiAmount(), principle,
						interest);
				tableList.add(display);
			}
			result = new ResponseEntity<>(tableList, HttpStatus.OK);
		}
		return result;
	}
	
	@ExceptionHandler(IBSException.class)
	public ResponseEntity<String> handleAdbException(IBSException exp) {
		return new ResponseEntity<String>(exp.getMessage(), HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(Exception.class)
	public ResponseEntity<String> handleException(Exception exp) {
		return new ResponseEntity<String>(exp.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
	}

}
