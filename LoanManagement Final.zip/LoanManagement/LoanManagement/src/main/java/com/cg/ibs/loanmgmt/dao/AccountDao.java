package com.cg.ibs.loanmgmt.dao;

import java.math.BigInteger;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.ibs.loanmgmt.entities.Account;
@Repository("accountDao")
public interface AccountDao extends JpaRepository<Account,BigInteger>{
}
