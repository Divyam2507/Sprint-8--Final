package com.cg.ibs.loanmgmt.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.ibs.loanmgmt.entities.LoanStatus;
import com.cg.ibs.loanmgmt.ibsexception.ExceptionMessages;
import com.cg.ibs.loanmgmt.ibsexception.IBSException;
import com.cg.ibs.loanmgmt.model.CustomerModel;
import com.cg.ibs.loanmgmt.model.LoanMasterModel;
import com.cg.ibs.loanmgmt.service.BankerService;
import com.cg.ibs.loanmgmt.service.CustomerService;
import com.cg.ibs.loanmgmt.service.VerifyLoanService;
import com.cg.ibs.loanmgmt.service.VerifyPreClosureService;

@RestController
@RequestMapping("/IBS/Banker")
@CrossOrigin
public class BankerController {
	@Autowired
	BankerService bankerService;
	@Autowired
	VerifyLoanService verifyLoanService;
	@Autowired
	CustomerService customerService;
	@Autowired
	VerifyPreClosureService verifyPreClosureLoans;

	@GetMapping("/appliedLoans")
	public ResponseEntity<List<LoanMasterModel>> getAllAppliedLoans() {
		ResponseEntity<List<LoanMasterModel>> result = null;
		List<LoanMasterModel> appliedLoans = bankerService.getAllAppliedLoans();

		if (appliedLoans.isEmpty()) {
			result = new ResponseEntity<List<LoanMasterModel>>(HttpStatus.NOT_FOUND);
		} else {
			result = new ResponseEntity<List<LoanMasterModel>>(appliedLoans, HttpStatus.OK);
		}
		return result;
	}

	@GetMapping("/getCustomer/{userId}")
	public ResponseEntity<CustomerModel> getCustomer(@PathVariable("userId") String userId) {
		ResponseEntity<CustomerModel> result = null;
		CustomerModel customer = customerService.getCustomer(userId);
		if (userId.equals(null)) {
			result = new ResponseEntity<CustomerModel>(HttpStatus.BAD_REQUEST);
		} else if (customer.equals(null)) {
			result = new ResponseEntity<CustomerModel>(HttpStatus.NOT_FOUND);
		} else {
			result = new ResponseEntity<CustomerModel>(customer, HttpStatus.OK);
		}
		return result;
	}

	@GetMapping("/preClosureLoans")
	public ResponseEntity<List<LoanMasterModel>> getAllAppliedPreClosureLoans() {
		ResponseEntity<List<LoanMasterModel>> result = null;
		List<LoanMasterModel> appliedPreLoans = bankerService.getAllAppliedPreClosureLoans();

		if (appliedPreLoans.isEmpty()) {
			result = new ResponseEntity<List<LoanMasterModel>>(HttpStatus.NOT_FOUND);
		} else {
			result = new ResponseEntity<List<LoanMasterModel>>(appliedPreLoans, HttpStatus.OK);
		}
		return result;
	}

	@GetMapping("/{userId}")
	public ResponseEntity<List<LoanMasterModel>> getBankerVerifyLoans(@PathVariable("userId") String userId) {
		ResponseEntity<List<LoanMasterModel>> result = null;
		System.out.println("insideBanker");
		System.out.println(userId);
		List<LoanMasterModel> bankerVerifyLoans = verifyLoanService.findLoansToBeVerified(userId);
		if (userId.equals(null)) {
			result = new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		} else if (bankerVerifyLoans.isEmpty()) {
			result = new ResponseEntity<>(HttpStatus.NOT_FOUND);
		} else {
			result = new ResponseEntity<>(bankerVerifyLoans, HttpStatus.OK);
		}
		return result;
	}

	@PostMapping("/{choice}")
	public ResponseEntity<LoanMasterModel> verifyLoan(@RequestBody LoanMasterModel loanMasterModel,
			@PathVariable("choice") Integer choice) throws IBSException {
		ResponseEntity<LoanMasterModel> result = null;
		System.out.println("hi verify");
		System.out.println(choice);
		LoanMasterModel verifiedLoan = new LoanMasterModel();
		if (choice == null && loanMasterModel.getApplicationNumber().equals(null)) {
			throw new IBSException(ExceptionMessages.MESSAGEFORWRONGINPUT);
		} else{
			verifiedLoan = verifyLoanService.verifyLoan(loanMasterModel, choice);
			result = new ResponseEntity<LoanMasterModel>(verifiedLoan, HttpStatus.OK);
		}
		return result;
	}

	@GetMapping("bankerVerifyPreClosure/{userId}")
	public ResponseEntity<List<LoanMasterModel>> getBankerPreClosureLoans(@PathVariable("userId") String userId) {
		ResponseEntity<List<LoanMasterModel>> result = null;
		List<LoanMasterModel> bankerPreClosureLoans = verifyPreClosureLoans.findPreClosureLoansToBeVerified(userId);
		if (userId.equals(null)) {
			result = new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		} else if (bankerPreClosureLoans.isEmpty()) {
			result = new ResponseEntity<>(HttpStatus.NOT_FOUND);
		} else {
			result = new ResponseEntity<>(bankerPreClosureLoans, HttpStatus.OK);
		}
		return result;
	}

	@PostMapping("preClose/{choice}")
	public ResponseEntity<LoanMasterModel> verifyPreClosure(@RequestBody LoanMasterModel loanMasterModel,
			@PathVariable("choice") Integer choice) {
		ResponseEntity<LoanMasterModel> result = null;
		LoanMasterModel preClosureLoan;

		if (choice == null && loanMasterModel.getLoanAccountNumber().equals(null)) {
			result = new ResponseEntity<LoanMasterModel>(HttpStatus.BAD_REQUEST);
		} else
			try {
				preClosureLoan = verifyPreClosureLoans.verifyPreClosure(loanMasterModel, choice);
				if (preClosureLoan.getStatus().equals(LoanStatus.PRE_CLOSED)) {
					result = new ResponseEntity<LoanMasterModel>(preClosureLoan, HttpStatus.OK);
				}
			} catch (IBSException e) {
				result = new ResponseEntity<LoanMasterModel>(HttpStatus.INTERNAL_SERVER_ERROR);
			}

		return result;
	}
	
	@ExceptionHandler(IBSException.class)
    public ResponseEntity<String> handleAdbException(IBSException exp) {
        return new ResponseEntity<String>(exp.getMessage(), HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<String> handleException(Exception exp) {
        return new ResponseEntity<String>(exp.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
    }
}
