package com.cg.ibs.loanmgmt.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDate;

import com.cg.ibs.loanmgmt.entities.LoanStatus;
import com.cg.ibs.loanmgmt.entities.LoanType;
import com.cg.ibs.loanmgmt.entities.PaymentMode;

public class LoanMasterModel implements Serializable{

	private BigInteger applicationNumber;
	private BigInteger loanAccountNumber;
	private BigDecimal loanAmount;
	private Integer loanTenure;
	private Integer loanTypeId;
	private LoanType loanType;
	private Float loanInterest;
	private BigDecimal balance;
	private LocalDate appliedDate;
	private Integer totalNumOfEmis;
	private Integer numOfEmisPaid;
	private BigDecimal emiAmount;
	private LoanStatus status;
	private LocalDate nextEmiDate;
	private LocalDate approvedDate;
	private LocalDate loanClosedDate;
	private LocalDate preclosureAppliedDate;
	private LocalDate preclosureApprovedDate;
	private LocalDate preclosureDeniedDate;
	private String customerUserId;
	private BigInteger savingsAccount;
	private LocalDate loanDeniedDate;
	private String remarks;
	
	
	public LocalDate getPreclosureDeniedDate() {
		return preclosureDeniedDate;
	}

	public void setPreclosureDeniedDate(LocalDate preclosureDeniedDate) {
		this.preclosureDeniedDate = preclosureDeniedDate;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public LocalDate getLoanDeniedDate() {
		return loanDeniedDate;
	}

	public void setLoanDeniedDate(LocalDate loanDeniedDate) {
		this.loanDeniedDate = loanDeniedDate;
	}

	public BigInteger getApplicationNumber() {
		return applicationNumber;
	}

	public void setApplicationNumber(BigInteger applicationNumber) {
		this.applicationNumber = applicationNumber;
	}

	public BigInteger getLoanAccountNumber() {
		return loanAccountNumber;
	}

	public void setLoanAccountNumber(BigInteger loanAccountNumber) {
		this.loanAccountNumber = loanAccountNumber;
	}

	public BigDecimal getLoanAmount() {
		return loanAmount;
	}

	public void setLoanAmount(BigDecimal loanAmount) {
		this.loanAmount = loanAmount;
	}

	public Integer getLoanTenure() {
		return loanTenure;
	}

	public void setLoanTenure(Integer loanTenure) {
		this.loanTenure = loanTenure;
	}

	public Integer getLoanTypeId() {
		return loanTypeId;
	}

	public void setLoanTypeId(Integer loanTypeId) {
		this.loanTypeId = loanTypeId;
	}


	public LoanType getLoanType() {
		return loanType;
	}

	public void setLoanType(LoanType loanType) {
		this.loanType = loanType;
	}

	public Float getLoanInterest() {
		return loanInterest;
	}

	public void setLoanInterest(Float loanInterest) {
		this.loanInterest = loanInterest;
	}

	public BigDecimal getBalance() {
		return balance;
	}

	public void setBalance(BigDecimal balance) {
		this.balance = balance;
	}


	public LocalDate getAppliedDate() {
		return appliedDate;
	}

	public void setAppliedDate(LocalDate appliedDate) {
		this.appliedDate = appliedDate;
	}

	public Integer getTotalNumOfEmis() {
		return totalNumOfEmis;
	}

	public void setTotalNumOfEmis(Integer totalNumOfEmis) {
		this.totalNumOfEmis = totalNumOfEmis;
	}

	public Integer getNumOfEmisPaid() {
		return numOfEmisPaid;
	}

	public void setNumOfEmisPaid(Integer numOfEmisPaid) {
		this.numOfEmisPaid = numOfEmisPaid;
	}

	public BigDecimal getEmiAmount() {
		return emiAmount;
	}

	public void setEmiAmount(BigDecimal emiAmount) {
		this.emiAmount = emiAmount;
	}

	public LoanStatus getStatus() {
		return status;
	}

	public void setStatus(LoanStatus status) {
		this.status = status;
	}

	public LocalDate getNextEmiDate() {
		return nextEmiDate;
	}

	public void setNextEmiDate(LocalDate nextEmiDate) {
		this.nextEmiDate = nextEmiDate;
	}

	public LocalDate getApprovedDate() {
		return approvedDate;
	}

	public void setApprovedDate(LocalDate approvedDate) {
		this.approvedDate = approvedDate;
	}

	public LocalDate getLoanClosedDate() {
		return loanClosedDate;
	}

	public void setLoanClosedDate(LocalDate loanClosedDate) {
		this.loanClosedDate = loanClosedDate;
	}

	public LocalDate getPreclosureAppliedDate() {
		return preclosureAppliedDate;
	}

	public void setPreclosureAppliedDate(LocalDate preclosureAppliedDate) {
		this.preclosureAppliedDate = preclosureAppliedDate;
	}

	public LocalDate getPreclosureApprovedDate() {
		return preclosureApprovedDate;
	}

	public void setPreclosureApprovedDate(LocalDate preclosureApprovedDate) {
		this.preclosureApprovedDate = preclosureApprovedDate;
	}

	public String getCustomerUserId() {
		return customerUserId;
	}

	public void setCustomerUserId(String customerUserId) {
		this.customerUserId = customerUserId;
	}

	public BigInteger getSavingsAccount() {
		return savingsAccount;
	}

	public void setSavingsAccount(BigInteger savingsAccount) {
		this.savingsAccount = savingsAccount;
	}

}
