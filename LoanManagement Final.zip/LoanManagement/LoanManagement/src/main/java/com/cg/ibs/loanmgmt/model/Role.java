package com.cg.ibs.loanmgmt.model;

public enum Role {
	CUSTOMER, BANKER
}
